Flash Flood — files from the 2026-08-31 session
===============================================

docs/
  story-bible.md                   The wordless story: premise, the pool-bar idea,
                                   the mother's visual rule, the ending, all 13
                                   chapters mapped onto the existing level groups,
                                   and the build/asset work it implies.
  gameplay-changes-2026-08-31.md   All six code changes from that day. Section 6 is
                                   the new one (Diverter/Splitter direction arrows).

code/
  HexBoard.gd                      Updated. Belongs at:
                                   game/scripts/gameplay/HexBoard.gd
                                   New: _draw_block_direction_arrows(),
                                   _block_target_offsets() (the one direction table
                                   both the simulation and the arrows read from),
                                   and the once-per-redraw preview cache
                                   (_preview_arrows / _preview_from_cells).
                                   No simulation behaviour changed.

characters/
  character-plates.html            Open in a browser. All 15 characters on hex
                                   tiles, the chapter mapping, a 58px legibility
                                   row, and the 5-state pool sequence with a play
                                   button. Every SVG is inline in this one file.
  svg/                             The 15 character SVGs, 100x100 viewBox, stroke
                                   #0b3d63 width 5 — same system as the existing
                                   assets/icons/ set. Godot imports SVG natively.
  png/                             200px renders of the same 15.
  pool-sequence/                   The 5 drinking-progress frames (svg + png).
  contact-sheet.png                All 15 on one sheet.
  pool-sequence-strip.png          The 5 frames in a row.

Status: first-pass concepts. The sheepdog, the crowd glyph (14_everyone) and the
mole are the three weakest reads and should be redrawn before anyone animates
them. Nothing in characters/ is wired into the engine yet.
